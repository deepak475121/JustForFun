//
//  thrCell.swift
//  justForFun
//
//  Created by Hari Crayond Digital Reach Pvt Ltd on 22/05/2017.
//  Copyright © 2017 Crayond Digital Reach Pvt Ltd. All rights reserved.
//

import UIKit

class thrCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
